/*
Navicat MySQL Data Transfer

Source Server         : test
Source Server Version : 80016
Source Host           : localhost:3306
Source Database       : db_dorm

Target Server Type    : MYSQL
Target Server Version : 80016
File Encoding         : 65001

Date: 2021-01-22 21:30:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_admin`
-- ----------------------------
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin` (
  `adminId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sex` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `tel` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`adminId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_admin
-- ----------------------------
INSERT INTO `t_admin` VALUES ('1', 'admin', '123', '系统管理员', '男', '123553666');
INSERT INTO `t_admin` VALUES ('2', 'zsr', 'zsr', '系统管理员', '男', '12321321321');

-- ----------------------------
-- Table structure for `t_dorm`
-- ----------------------------
DROP TABLE IF EXISTS `t_dorm`;
CREATE TABLE `t_dorm` (
  `dormId` int(11) NOT NULL AUTO_INCREMENT,
  `dormBuildId` int(11) DEFAULT NULL,
  `dormName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dormType` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dormNumber` int(11) DEFAULT NULL,
  `dormTel` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`dormId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_dorm
-- ----------------------------
INSERT INTO `t_dorm` VALUES ('1', '1', '220', '男', '6', '110');

-- ----------------------------
-- Table structure for `t_dormbuild`
-- ----------------------------
DROP TABLE IF EXISTS `t_dormbuild`;
CREATE TABLE `t_dormbuild` (
  `dormBuildId` int(11) NOT NULL AUTO_INCREMENT,
  `dormBuildName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dormBuildDetail` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`dormBuildId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_dormbuild
-- ----------------------------
INSERT INTO `t_dormbuild` VALUES ('4', '2栋', '这是2栋');
INSERT INTO `t_dormbuild` VALUES ('5', '3栋', '啥也不想说');
INSERT INTO `t_dormbuild` VALUES ('6', '4栋', '这里是第四栋');
INSERT INTO `t_dormbuild` VALUES ('8', '6栋啊啊', '人生充满了无奈，但是还得咬牙坚持');

-- ----------------------------
-- Table structure for `t_dormmanager`
-- ----------------------------
DROP TABLE IF EXISTS `t_dormmanager`;
CREATE TABLE `t_dormmanager` (
  `dormManId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dormBuildId` int(11) DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sex` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `tel` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`dormManId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=416 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_dormmanager
-- ----------------------------
INSERT INTO `t_dormmanager` VALUES ('8', 'manager1', '123', '4', '小白', '男', '123');
INSERT INTO `t_dormmanager` VALUES ('415', 'zsr', '123', '415', '张三', '男', '110');

-- ----------------------------
-- Table structure for `t_notice`
-- ----------------------------
DROP TABLE IF EXISTS `t_notice`;
CREATE TABLE `t_notice` (
  `noticeId` int(11) NOT NULL AUTO_INCREMENT,
  `noticePerson` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`noticeId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_notice
-- ----------------------------
INSERT INTO `t_notice` VALUES ('1', '', '2020-09-23', '欢迎你访问，祝你学习愉快。');

-- ----------------------------
-- Table structure for `t_punchclock`
-- ----------------------------
DROP TABLE IF EXISTS `t_punchclock`;
CREATE TABLE `t_punchclock` (
  `id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `theme` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_punchclock
-- ----------------------------
INSERT INTO `t_punchclock` VALUES ('pcId1601007599477', '测试打卡', '测试打卡功能555', '2020-09-25', 'admin');
INSERT INTO `t_punchclock` VALUES ('pcId1601008207725', 'ddd', 'dddd', '2020-09-25', 'admin');

-- ----------------------------
-- Table structure for `t_punchclockrecord`
-- ----------------------------
DROP TABLE IF EXISTS `t_punchclockrecord`;
CREATE TABLE `t_punchclockrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `punchClock_id` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `punchClock_date` date DEFAULT NULL,
  `punchClock_theme` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `punchClock_detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `punchClock_person` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dormName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `tel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `stuNum` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dormBuildId` int(11) DEFAULT NULL,
  `isRecord` tinyint(255) DEFAULT NULL,
  `punckClock_content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_punchclockrecord
-- ----------------------------
INSERT INTO `t_punchclockrecord` VALUES ('46', 'pcId1601007599477', '2020-09-25', '测试打卡', '测试打卡功能555', 'admin', '李xiaosi', '120', '323456', '002', '4', '1', '带上er');
INSERT INTO `t_punchclockrecord` VALUES ('47', 'pcId1601007599477', '2020-09-25', '测试打卡', '测试打卡功能555', 'admin', '李四2', '120', '32', '0023', '4', '0', null);
INSERT INTO `t_punchclockrecord` VALUES ('48', 'pcId1601007599477', '2020-09-25', '测试打卡', '测试打卡功能555', 'admin', '李四5', '120', '32', '0023999', '3', '0', null);
INSERT INTO `t_punchclockrecord` VALUES ('49', 'pcId1601007599477', '2020-09-25', '测试打卡', '测试打卡功能555', 'admin', '普通用户', '234234', '324', '23423', '324', '0', null);
INSERT INTO `t_punchclockrecord` VALUES ('50', 'pcId1601007599477', '2020-09-25', '测试打卡', '测试打卡功能555', 'admin', '西郊小', '789', '897', '444', '567', '0', null);
INSERT INTO `t_punchclockrecord` VALUES ('51', 'pcId1601008207725', '2020-09-25', 'ddd', 'dddd', 'admin', '李xiaosi', '120', '323456', '002', '4', '1', 'sdfdds');
INSERT INTO `t_punchclockrecord` VALUES ('52', 'pcId1601008207725', '2020-09-25', 'ddd', 'dddd', 'admin', '李四2', '120', '32', '0023', '4', '0', '');
INSERT INTO `t_punchclockrecord` VALUES ('53', 'pcId1601008207725', '2020-09-25', 'ddd', 'dddd', 'admin', '李四5', '120', '32', '0023999', '3', '0', '');
INSERT INTO `t_punchclockrecord` VALUES ('54', 'pcId1601008207725', '2020-09-25', 'ddd', 'dddd', 'admin', '普通用户', '234234', '324', '23423', '324', '0', '');
INSERT INTO `t_punchclockrecord` VALUES ('55', 'pcId1601008207725', '2020-09-25', 'ddd', 'dddd', 'admin', '西郊小', '789', '897', '444', '567', '0', '');

-- ----------------------------
-- Table structure for `t_record`
-- ----------------------------
DROP TABLE IF EXISTS `t_record`;
CREATE TABLE `t_record` (
  `recordId` int(11) NOT NULL AUTO_INCREMENT,
  `studentNumber` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `studentName` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dormBuildId` int(11) DEFAULT NULL,
  `dormName` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `detail` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`recordId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_record
-- ----------------------------
INSERT INTO `t_record` VALUES ('1', '201916127111', '张三', '415', '415', '2021-01-21', '迟到');
INSERT INTO `t_record` VALUES ('3', '007', '测试1', '1', '221', '2021-01-21', '未按时签到');

-- ----------------------------
-- Table structure for `t_student`
-- ----------------------------
DROP TABLE IF EXISTS `t_student`;
CREATE TABLE `t_student` (
  `studentId` int(11) NOT NULL AUTO_INCREMENT,
  `stuNum` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `dormBuildId` int(11) DEFAULT NULL,
  `dormName` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `sex` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `tel` varchar(15) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`studentId`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of t_student
-- ----------------------------
INSERT INTO `t_student` VALUES ('1', '0023', '123', '张三', '415', '415', '男', '110');
INSERT INTO `t_student` VALUES ('2', '0024', '123', '李四', '416', '416', '男', '120');
INSERT INTO `t_student` VALUES ('3', '0025', '123', '王五', '417', '417', '男', '119');
